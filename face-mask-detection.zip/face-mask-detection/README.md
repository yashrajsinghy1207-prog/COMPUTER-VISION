# Real-Time Face Mask Detection

A Computer Vision system that detects whether a person **is or is not wearing
a face mask**, in a static image, a video file, or a live webcam stream —
in real time, from the command line.

The pipeline has two stages:

1. **Face localization** — OpenCV's pretrained SSD (ResNet-10 backbone,
   Caffe framework) finds every face in a frame.
2. **Mask classification** — a MobileNetV2 network, fine-tuned via transfer
   learning on a labeled mask / no-mask dataset, classifies each detected
   face.

The two-stage design keeps the model lightweight enough to run in real time
on a normal CPU (no GPU required).

---

## Project Structure

```
face-mask-detection/
├── README.md
├── requirements.txt
├── .gitignore
├── src/
│   ├── model.py            # Model architecture (MobileNetV2 + custom head)
│   ├── train.py            # Trains the mask classifier on data/raw/
│   ├── detect_image.py     # Run detection on a single image
│   ├── detect_video.py     # Run detection on a video file / webcam
│   └── utils.py            # Shared face-detection + prediction helpers
├── face_detector/          # OpenCV face-detector files (you download these — see below)
├── data/
│   ├── raw/                # Training dataset (you download this — see below)
│   │   ├── with_mask/
│   │   └── without_mask/
│   └── sample_images/      # Put a few test images here for quick demos
├── models/                 # Trained model is saved here (mask_detector.model)
├── outputs/                # Annotated images/videos and training plots land here
└── report/                 # Project report
```

---

## 1. Environment Setup

**Requirements:** Python 3.9–3.11 (TensorFlow 2.15 does not yet support 3.12+).

```bash
# 1. Clone the repository
git clone https://github.com/{your-username}/{your-repo-name}.git
cd {your-repo-name}

# 2. Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 2. Download the Face Detector (required, ~10 MB)

This is OpenCV's generic pretrained face locator (not our mask model).
Download both files into the `face_detector/` folder:

```bash
cd face_detector

curl -o deploy.prototxt https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt

curl -L -o res10_300x300_ssd_iter_140000.caffemodel https://raw.githubusercontent.com/opencv/opencv_3rdparty/dnn_samples_face_detector_20170830/res10_300x300_ssd_iter_140000.caffemodel

cd ..
```

You should now have:
```
face_detector/
├── deploy.prototxt
└── res10_300x300_ssd_iter_140000.caffemodel
```

---

## 3. Get the Dataset (required for training)

This project uses the public **Face Mask Detection Dataset** (~4,000 images,
two classes: `with_mask`, `without_mask`). Any similarly-labeled dataset will
work.

Recommended source (Kaggle):
`https://www.kaggle.com/datasets/omkargurav/face-mask-dataset`

```bash
# Requires a Kaggle account + API token (~/.kaggle/kaggle.json)
pip install kaggle
kaggle datasets download -d omkargurav/face-mask-dataset -p data/raw --unzip
```

After extracting, arrange the files so the structure matches exactly:

```
data/raw/
├── with_mask/
│   ├── 0001.jpg
│   └── ...
└── without_mask/
    ├── 0001.jpg
    └── ...
```

> A pretrained model is **not** committed to this repository (weight files
> are large and datasets are licensed for redistribution by their owners
> only). You must train it yourself using the steps below — this takes
> roughly 5–15 minutes on a CPU for 20 epochs on ~4,000 images.

---

## 4. Train the Model

```bash
python src/train.py \
    --dataset data/raw \
    --model models/mask_detector.model \
    --plot outputs/training_plot.png \
    --epochs 20
```

This will:
- Load and preprocess every image in `data/raw/with_mask` and `data/raw/without_mask`
- Split 80% train / 20% test
- Fine-tune a MobileNetV2-based classifier
- Print a classification report (precision/recall/F1) on the held-out test set
- Save the trained model to `models/mask_detector.model`
- Save a loss/accuracy curve to `outputs/training_plot.png`

Run `python src/train.py --help` to see all configurable options
(epochs, batch size, learning rate, paths).

---

## 5. Run Detection

### On a single image

```bash
python src/detect_image.py \
    --image data/sample_images/test1.jpg \
    --face-detector face_detector \
    --model models/mask_detector.model \
    --output outputs/test1_annotated.jpg
```

### On a video file

```bash
python src/detect_video.py \
    --input path/to/video.mp4 \
    --output outputs/video_annotated.mp4 \
    --face-detector face_detector \
    --model models/mask_detector.model \
    --no-display
```

### On a live webcam (press `q` to quit)

```bash
python src/detect_video.py \
    --face-detector face_detector \
    --model models/mask_detector.model
```

> Use `--no-display` on any headless / server / CI environment that has no
> GUI or attached camera — the script still runs, it just won't try to open
> a window.

Each detected face is boxed with a **green "Mask"** or **red "No Mask"**
label and a confidence percentage.

---

## 6. Command-Line Reference

| Script | Purpose | Key flags |
|---|---|---|
| `src/train.py` | Train the classifier | `--dataset`, `--model`, `--epochs`, `--batch-size`, `--learning-rate`, `--plot` |
| `src/detect_image.py` | Detect on one image | `--image`, `--face-detector`, `--model`, `--confidence`, `--output` |
| `src/detect_video.py` | Detect on video/webcam | `--input`, `--output`, `--face-detector`, `--model`, `--confidence`, `--no-display` |

Run any script with `--help` for the full list of options.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `FileNotFoundError: Face detector files not found` | You skipped step 2 — download the two files into `face_detector/`. |
| `RuntimeError: No images found under 'data/raw'` | You skipped step 3 — download and correctly place the dataset. |
| Training is very slow | Reduce `--epochs`, or reduce dataset size for a quick sanity check first. |
| Webcam window doesn't open on a remote server | Use `--input <video-file>` with `--no-display` instead of the webcam — servers rarely have GUI/camera access. |
| `ModuleNotFoundError` for any package | Re-run `pip install -r requirements.txt` inside your activated virtual environment. |

---

## Tech Stack

- **Python 3**
- **TensorFlow / Keras** — MobileNetV2 transfer learning
- **OpenCV (cv2)** — DNN face detector + drawing/video I/O
- **imutils** — convenience video-stream and resize helpers
- **scikit-learn** — train/test split, classification report

---

## Report

See [`report/Project_Report.md`](report/Project_Report.md) (also exported
as `report/Project_Report.pdf`) for the full write-up: problem statement,
methodology, architecture, dataset details, results, and limitations.
