"""
detect_image.py
----------------
Run face-mask detection on a single static image.

Usage
-----
    python src/detect_image.py \
        --image data/sample_images/test1.jpg \
        --face-detector face_detector \
        --model models/mask_detector.model \
        --output outputs/test1_annotated.jpg

Run `python src/detect_image.py --help` for all options.
"""

import argparse
import os

import cv2
from tensorflow.keras.models import load_model

from utils import detect_and_predict_mask, load_face_detector


def parse_args():
    parser = argparse.ArgumentParser(description="Detect face masks in an image.")
    parser.add_argument("--image", required=True, help="Path to the input image.")
    parser.add_argument(
        "--face-detector",
        default="face_detector",
        help="Path to the folder containing the OpenCV face detector files.",
    )
    parser.add_argument(
        "--model",
        default="models/mask_detector.model",
        help="Path to the trained mask-classifier model.",
    )
    parser.add_argument(
        "--confidence",
        type=float,
        default=0.5,
        help="Minimum probability to filter weak face detections.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Path to save the annotated output image. If omitted, a window "
        "is shown instead (requires a display).",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    print("[INFO] loading face detector model...")
    face_net = load_face_detector(args.face_detector)

    print("[INFO] loading mask detector model...")
    mask_net = load_model(args.model)

    image = cv2.imread(args.image)
    if image is None:
        raise FileNotFoundError(f"Could not read image at '{args.image}'.")

    locations, predictions = detect_and_predict_mask(
        image, face_net, mask_net, confidence_threshold=args.confidence
    )

    for (box, pred) in zip(locations, predictions):
        (start_x, start_y, end_x, end_y) = box
        (mask_prob, without_mask_prob) = pred

        label = "Mask" if mask_prob > without_mask_prob else "No Mask"
        color = (0, 255, 0) if label == "Mask" else (0, 0, 255)

        label_text = f"{label}: {max(mask_prob, without_mask_prob) * 100:.1f}%"

        cv2.putText(
            image,
            label_text,
            (start_x, max(start_y - 10, 20)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            color,
            2,
        )
        cv2.rectangle(image, (start_x, start_y), (end_x, end_y), color, 2)

    print(f"[INFO] detected {len(locations)} face(s).")

    if args.output:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        cv2.imwrite(args.output, image)
        print(f"[INFO] annotated image saved to '{args.output}'")
    else:
        cv2.imshow("Mask Detector", image)
        cv2.waitKey(0)
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
