"""
utils.py
--------
Shared helper functions used by both detect_image.py and detect_video.py.
"""

import os
import cv2
import numpy as np
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array


def load_face_detector(face_detector_dir):
    """
    Load OpenCV's pretrained Caffe-based face detector (an SSD with a
    ResNet-10 backbone). This is *not* our mask classifier -- it is a
    generic, off-the-shelf face locator used purely to crop face regions
    out of a frame before we hand them to our mask-detection model.

    Expects two files inside `face_detector_dir`:
        - deploy.prototxt
        - res10_300x300_ssd_iter_140000.caffemodel
    (Download instructions are in the README.)
    """
    prototxt_path = os.path.join(face_detector_dir, "deploy.prototxt")
    weights_path = os.path.join(
        face_detector_dir, "res10_300x300_ssd_iter_140000.caffemodel"
    )

    if not os.path.exists(prototxt_path) or not os.path.exists(weights_path):
        raise FileNotFoundError(
            "Face detector files not found in '{}'.\n"
            "Please download them as described in the README "
            "(section: 'Download the face detector').".format(face_detector_dir)
        )

    net = cv2.dnn.readNet(prototxt_path, weights_path)
    return net


def detect_and_predict_mask(frame, face_net, mask_net, confidence_threshold=0.5):
    """
    Run the two-stage pipeline on a single BGR frame:
      1. Locate all faces in the frame using `face_net`.
      2. For each face, run `mask_net` to classify mask / no-mask.

    Returns
    -------
    locations : list of (startX, startY, endX, endY) bounding boxes
    predictions : list of (mask_prob, without_mask_prob) tuples, one per face
    """
    (h, w) = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(
        frame, 1.0, (300, 300), (104.0, 177.0, 123.0)
    )

    face_net.setInput(blob)
    detections = face_net.forward()

    faces = []
    locations = []
    predictions = []

    for i in range(detections.shape[2]):
        confidence = detections[0, 0, i, 2]

        if confidence < confidence_threshold:
            continue

        box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
        (start_x, start_y, end_x, end_y) = box.astype("int")

        # Clamp bounding boxes to the frame dimensions.
        start_x, start_y = max(0, start_x), max(0, start_y)
        end_x, end_y = min(w - 1, end_x), min(h - 1, end_y)

        face = frame[start_y:end_y, start_x:end_x]
        if face.size == 0:
            continue

        face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
        face = cv2.resize(face, (224, 224))
        face = img_to_array(face)
        face = preprocess_input(face)

        faces.append(face)
        locations.append((start_x, start_y, end_x, end_y))

    if len(faces) > 0:
        faces = np.array(faces, dtype="float32")
        predictions = mask_net.predict(faces, batch_size=32, verbose=0)

    return locations, predictions
