"""
train.py
--------
Trains the face-mask classifier on the dataset in data/raw/.

Expected dataset layout (see README for download link):

    data/raw/
        with_mask/
            img1.jpg
            img2.jpg
            ...
        without_mask/
            img1.jpg
            img2.jpg
            ...

Usage
-----
    python src/train.py \
        --dataset data/raw \
        --model models/mask_detector.model \
        --plot outputs/training_plot.png \
        --epochs 20

Run `python src/train.py --help` for all options.
"""

import argparse
import os

import matplotlib

matplotlib.use("Agg")  # allow plotting without a display (headless servers)
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import (
    ImageDataGenerator,
    img_to_array,
    load_img,
)
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.utils import to_categorical

from model import build_mask_detector, IMG_SIZE


def parse_args():
    parser = argparse.ArgumentParser(description="Train the face mask detector.")
    parser.add_argument(
        "--dataset",
        default="data/raw",
        help="Path to the input dataset (must contain with_mask/ and without_mask/ subfolders).",
    )
    parser.add_argument(
        "--model",
        default="models/mask_detector.model",
        help="Path where the trained model will be saved (SavedModel/H5 format).",
    )
    parser.add_argument(
        "--plot",
        default="outputs/training_plot.png",
        help="Path where the loss/accuracy plot will be saved.",
    )
    parser.add_argument("--epochs", type=int, default=20, help="Number of training epochs.")
    parser.add_argument("--batch-size", type=int, default=32, help="Training batch size.")
    parser.add_argument(
        "--learning-rate", type=float, default=1e-4, help="Initial learning rate."
    )
    return parser.parse_args()


def load_dataset(dataset_path):
    """Load images and labels from the dataset directory into memory."""
    image_paths = []
    for label in ("with_mask", "without_mask"):
        label_dir = os.path.join(dataset_path, label)
        if not os.path.isdir(label_dir):
            raise FileNotFoundError(
                f"Expected subfolder '{label}' inside '{dataset_path}'. "
                "See README for the expected dataset layout."
            )
        for filename in os.listdir(label_dir):
            if filename.lower().endswith((".jpg", ".jpeg", ".png")):
                image_paths.append((os.path.join(label_dir, filename), label))

    if len(image_paths) == 0:
        raise RuntimeError(
            f"No images found under '{dataset_path}'. Did you download and "
            "extract the dataset? See README section 'Get the dataset'."
        )

    data, labels = [], []
    print(f"[INFO] loading {len(image_paths)} images...")
    for path, label in image_paths:
        image = load_img(path, target_size=IMG_SIZE)
        image = img_to_array(image)
        image = preprocess_input(image)
        data.append(image)
        labels.append(label)

    data = np.array(data, dtype="float32")
    labels = np.array(labels)
    return data, labels


def main():
    args = parse_args()

    os.makedirs(os.path.dirname(args.model) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(args.plot) or ".", exist_ok=True)

    data, labels = load_dataset(args.dataset)

    # One-hot encode the string labels ("with_mask" / "without_mask").
    label_binarizer = LabelBinarizer()
    labels = label_binarizer.fit_transform(labels)
    labels = to_categorical(labels)
    class_names = label_binarizer.classes_
    print(f"[INFO] classes: {list(class_names)}")

    (train_x, test_x, train_y, test_y) = train_test_split(
        data, labels, test_size=0.20, stratify=labels, random_state=42
    )

    # Light augmentation to help generalization on a modest dataset size.
    augmentor = ImageDataGenerator(
        rotation_range=20,
        zoom_range=0.15,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.15,
        horizontal_flip=True,
        fill_mode="nearest",
    )

    model, base_model = build_mask_detector(input_shape=(IMG_SIZE[0], IMG_SIZE[1], 3))

    optimizer = Adam(learning_rate=args.learning_rate)
    model.compile(
        loss="binary_crossentropy",
        optimizer=optimizer,
        metrics=["accuracy"],
    )

    print("[INFO] training head of the network...")
    history = model.fit(
        augmentor.flow(train_x, train_y, batch_size=args.batch_size),
        steps_per_epoch=len(train_x) // args.batch_size,
        validation_data=(test_x, test_y),
        validation_steps=len(test_x) // args.batch_size,
        epochs=args.epochs,
    )

    print("[INFO] evaluating network...")
    pred_idxs = model.predict(test_x, batch_size=args.batch_size)
    pred_idxs = np.argmax(pred_idxs, axis=1)
    print(
        classification_report(
            test_y.argmax(axis=1), pred_idxs, target_names=class_names
        )
    )

    print(f"[INFO] saving mask detector model to '{args.model}'...")
    model.save(args.model, save_format="h5")

    # Plot training/validation loss and accuracy.
    n_epochs = args.epochs
    plt.style.use("ggplot")
    plt.figure()
    plt.plot(np.arange(0, n_epochs), history.history["loss"], label="train_loss")
    plt.plot(np.arange(0, n_epochs), history.history["val_loss"], label="val_loss")
    plt.plot(np.arange(0, n_epochs), history.history["accuracy"], label="train_acc")
    plt.plot(np.arange(0, n_epochs), history.history["val_accuracy"], label="val_acc")
    plt.title("Training Loss and Accuracy")
    plt.xlabel("Epoch #")
    plt.ylabel("Loss / Accuracy")
    plt.legend(loc="lower left")
    plt.savefig(args.plot)
    print(f"[INFO] training plot saved to '{args.plot}'")


if __name__ == "__main__":
    main()
