"""
detect_video.py
----------------
Run real-time face-mask detection on a webcam feed or a video file.

Usage (webcam)
--------------
    python src/detect_video.py --face-detector face_detector --model models/mask_detector.model

Usage (video file, saving annotated output, no GUI window)
------------------------------------------------------------
    python src/detect_video.py \
        --input videos/sample.mp4 \
        --output outputs/sample_annotated.mp4 \
        --face-detector face_detector \
        --model models/mask_detector.model \
        --no-display

Press 'q' to quit the live window (when --no-display is not set).

Run `python src/detect_video.py --help` for all options.
"""

import argparse
import os
import time

import cv2
import imutils
from imutils.video import VideoStream
from tensorflow.keras.models import load_model

from utils import detect_and_predict_mask, load_face_detector


def parse_args():
    parser = argparse.ArgumentParser(
        description="Detect face masks in a video stream (webcam or file)."
    )
    parser.add_argument(
        "--input",
        default=None,
        help="Path to an input video file. If omitted, the webcam is used.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Path to save the annotated output video (mp4). Optional.",
    )
    parser.add_argument(
        "--face-detector",
        default="face_detector",
        help="Path to the folder containing the OpenCV face detector files.",
    )
    parser.add_argument(
        "--model",
        default="models/mask_detector.model",
        help="Path to the trained mask-classifier model.",
    )
    parser.add_argument(
        "--confidence",
        type=float,
        default=0.5,
        help="Minimum probability to filter weak face detections.",
    )
    parser.add_argument(
        "--no-display",
        action="store_true",
        help="Do not open a GUI window (useful for headless/CLI-only environments).",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    print("[INFO] loading face detector model...")
    face_net = load_face_detector(args.face_detector)

    print("[INFO] loading mask detector model...")
    mask_net = load_model(args.model)

    if args.input:
        print(f"[INFO] opening video file '{args.input}'...")
        vs = cv2.VideoCapture(args.input)
        is_file = True
    else:
        print("[INFO] starting webcam stream...")
        vs = VideoStream(src=0).start()
        is_file = False
        time.sleep(2.0)  # let the camera sensor warm up

    writer = None

    while True:
        if is_file:
            grabbed, frame = vs.read()
            if not grabbed:
                break
        else:
            frame = vs.read()
            if frame is None:
                break

        frame = imutils.resize(frame, width=800)

        locations, predictions = detect_and_predict_mask(
            frame, face_net, mask_net, confidence_threshold=args.confidence
        )

        for (box, pred) in zip(locations, predictions):
            (start_x, start_y, end_x, end_y) = box
            (mask_prob, without_mask_prob) = pred

            label = "Mask" if mask_prob > without_mask_prob else "No Mask"
            color = (0, 255, 0) if label == "Mask" else (0, 0, 255)
            label_text = f"{label}: {max(mask_prob, without_mask_prob) * 100:.1f}%"

            cv2.putText(
                frame,
                label_text,
                (start_x, max(start_y - 10, 20)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                color,
                2,
            )
            cv2.rectangle(frame, (start_x, start_y), (end_x, end_y), color, 2)

        if args.output:
            if writer is None:
                os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
                fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                (h, w) = frame.shape[:2]
                writer = cv2.VideoWriter(args.output, fourcc, 20, (w, h))
            writer.write(frame)

        if not args.no_display:
            cv2.imshow("Mask Detector - press 'q' to quit", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break

    if writer is not None:
        writer.release()
        print(f"[INFO] annotated video saved to '{args.output}'")

    if is_file:
        vs.release()
    else:
        vs.stop()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
