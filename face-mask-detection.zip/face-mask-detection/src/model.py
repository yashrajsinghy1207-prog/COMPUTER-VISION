"""
model.py
--------
Defines the mask-classification model architecture.

We use transfer learning on top of MobileNetV2 (pretrained on ImageNet).
MobileNetV2 is chosen because it is lightweight and fast enough to run
in real time on CPU, which matters for the video/webcam demo.

The base network is frozen during training so we only learn a small
"head" classifier on top -- this lets the model train in a few minutes
on a modest dataset (a few thousand images) without a GPU.
"""

from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import (
    AveragePooling2D,
    Dropout,
    Flatten,
    Dense,
    Input,
)
from tensorflow.keras.models import Model


IMG_SIZE = (224, 224)


def build_mask_detector(input_shape=(224, 224, 3), num_classes=2):
    """
    Build and return an (uncompiled) mask-detector Keras model.

    Parameters
    ----------
    input_shape : tuple
        Shape of the input images fed to the network.
    num_classes : int
        Number of output classes. 2 -> [with_mask, without_mask].

    Returns
    -------
    model : tf.keras.Model
    base_model : tf.keras.Model
        Reference to the MobileNetV2 backbone, returned separately so the
        training script can freeze/unfreeze its layers explicitly.
    """
    # Load MobileNetV2, pretrained on ImageNet, without its top
    # classification layer (we add our own head below).
    base_model = MobileNetV2(
        weights="imagenet",
        include_top=False,
        input_tensor=Input(shape=input_shape),
    )

    # Construct the classification head that will sit on top of the
    # frozen backbone.
    head_model = base_model.output
    head_model = AveragePooling2D(pool_size=(7, 7))(head_model)
    head_model = Flatten(name="flatten")(head_model)
    head_model = Dense(128, activation="relu")(head_model)
    head_model = Dropout(0.5)(head_model)
    head_model = Dense(num_classes, activation="softmax")(head_model)

    model = Model(inputs=base_model.input, outputs=head_model)

    # Freeze the backbone so only the head is trained initially.
    for layer in base_model.layers:
        layer.trainable = False

    return model, base_model
