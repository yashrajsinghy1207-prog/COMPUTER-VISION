Place the two OpenCV face-detector files here (see main README for exact
download links):
  - deploy.prototxt
  - res10_300x300_ssd_iter_140000.caffemodel
