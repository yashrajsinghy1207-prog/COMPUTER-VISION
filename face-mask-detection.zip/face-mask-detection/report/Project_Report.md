---
title: "Real-Time Face Mask Detection System"
subtitle: "Computer Vision — Flipped Course Evaluation Project"
author: "[Your Name] — [Your Registration Number]"
date: "September 2026"
---

# 1. Introduction

## 1.1 Problem Statement
Manual monitoring of mask compliance in public spaces (hospitals, offices,
transit hubs) is labor-intensive and inconsistent. This project builds an
automated **Computer Vision system that detects, in real time, whether a
person in an image, video, or live camera feed is wearing a face mask**.

## 1.2 Motivation
Face-mask compliance detection became a widely deployed real-world CV
application during the COVID-19 pandemic and remains a useful case study
because it combines two classic CV sub-problems — **object (face)
detection** and **image classification** — into a single practical
pipeline that must run in real time on modest hardware.

## 1.3 Objectives
1. Detect all human faces present in a frame.
2. Classify each detected face as **"Mask"** or **"No Mask"**.
3. Run the complete pipeline on static images, recorded video, and a live
   webcam feed, from the command line, without requiring a GPU.

---

# 2. Related Work / Background

Face detection has historically relied on handcrafted-feature detectors
(e.g., Viola–Jones Haar cascades). This project instead uses a deep
learning-based face detector — an SSD (Single Shot Detector) with a
ResNet-10 backbone, distributed with OpenCV's `dnn` module — which is far
more robust to pose, lighting, and partial occlusion than Haar cascades.

For the mask/no-mask classification stage, **transfer learning** is used
rather than training a convolutional network from scratch. Training from
scratch would require a very large labeled dataset and significant compute
to reach good accuracy; instead, we reuse **MobileNetV2**, a network
pretrained on ImageNet, and fine-tune only a small classification head on
top of it. MobileNetV2 was chosen specifically (over larger backbones like
ResNet50 or VGG16) because its depth-wise separable convolutions make it
fast enough for real-time inference on CPU-only machines.

---

# 3. System Architecture

```
                 ┌───────────────────────┐
   Input Frame → │  Face Detector (SSD /  │ → Face bounding boxes
  (image/video/  │  ResNet-10, OpenCV DNN)│
   webcam)       └───────────────────────┘
                            │
                for each detected face crop
                            ▼
                 ┌───────────────────────┐
                 │  Mask Classifier       │ → "Mask" / "No Mask"
                 │  (MobileNetV2 + head)  │    + confidence score
                 └───────────────────────┘
                            │
                            ▼
                 Annotated frame (bounding box
                 + label + confidence, color-coded)
```

**Stage 1 — Face Detection.** Every frame is passed through OpenCV's
pretrained Caffe SSD face detector. Detections below a confidence threshold
(default 0.5) are discarded. Each surviving detection yields a bounding box
which is cropped out of the frame.

**Stage 2 — Mask Classification.** Each cropped face is resized to
224×224, converted to RGB, and preprocessed using MobileNetV2's standard
preprocessing function. The custom classification head consists of:

```
MobileNetV2 (frozen, ImageNet weights, include_top=False)
        → AveragePooling2D(7×7)
        → Flatten
        → Dense(128, ReLU)
        → Dropout(0.5)
        → Dense(2, Softmax)   # [with_mask, without_mask]
```

Freezing the MobileNetV2 backbone during training means only ~1.3M
parameters in the head are updated, which is why training converges in
minutes on a CPU rather than hours.

**Stage 3 — Output.** Bounding boxes are drawn on the original frame:
green for "Mask", red for "No Mask", each labeled with the model's
confidence percentage.

---

# 4. Dataset

- **Source:** Public Face Mask Detection Dataset (Kaggle,
  `omkargurav/face-mask-dataset`), ~4,000 images across two balanced
  classes (`with_mask`, `without_mask`).
- **Preprocessing:** All images resized to 224×224 and normalized via
  MobileNetV2's `preprocess_input`.
- **Split:** 80% training / 20% held-out test (stratified by class).
- **Augmentation:** Random rotation (±20°), zoom (±15%), width/height
  shift (±20%), shear (±15%), and horizontal flip — applied only to the
  training set, to reduce overfitting given the moderate dataset size.

---

# 5. Training Configuration

| Hyperparameter | Value |
|---|---|
| Base network | MobileNetV2 (ImageNet weights, frozen) |
| Optimizer | Adam |
| Learning rate | 1e-4 |
| Loss function | Binary cross-entropy |
| Batch size | 32 |
| Epochs | 20 |
| Input size | 224 × 224 × 3 |

Training and evaluation code: `src/train.py`. Running it reproduces the
full pipeline: data loading → augmentation → training → held-out
evaluation (precision/recall/F1 report) → model + training-curve export.

---

# 6. Results

> Fill in this section with your actual numbers after running
> `python src/train.py`. The script prints a full
> `sklearn.metrics.classification_report` on the held-out test set and
> saves a loss/accuracy curve to `outputs/training_plot.png` — paste the
> table and embed the plot image here.

Example of the expected report shape:

| Class | Precision | Recall | F1-score | Support |
|---|---|---|---|---|
| with_mask | ~0.98 | ~0.99 | ~0.98 | — |
| without_mask | ~0.99 | ~0.98 | ~0.98 | — |

Qualitative results (screenshots from `detect_image.py` / `detect_video.py`
runs) should also be included here: original frame vs. annotated output,
for at least one "Mask" and one "No Mask" example.

---

# 7. Real-Time Inference Design Choices

- **Two decoupled models** (face detector + classifier) rather than one
  end-to-end detector, so each stage can be swapped/upgraded independently
  (e.g., replacing the face detector with a faster/more accurate one
  without retraining the classifier).
- **Frozen backbone** to keep both training and inference fast enough for
  CPU-only, real-time operation (webcam demo runs without a GPU).
- **Confidence thresholding** on face detections to suppress false
  positives before they reach the classifier.
- **CLI-first design**: all three scripts (`train.py`, `detect_image.py`,
  `detect_video.py`) are pure command-line tools with `argparse` interfaces
  and a `--no-display` flag, so the entire project runs in headless/server
  environments with no GUI dependency.

---

# 8. Limitations & Future Work

- **Lighting/angle sensitivity**: like most face detectors, accuracy drops
  under poor lighting or extreme face angles.
- **Mask-type generalization**: the dataset does not distinguish between
  mask types (surgical, cloth, N95) or partial/improper wear (mask below
  nose) — a finer-grained multi-class model could address this.
- **Single-frame classification**: no temporal smoothing across video
  frames; a simple majority-vote over a sliding window of frames could
  reduce flicker in the live-video demo.
- **Edge deployment**: MobileNetV2 was chosen with edge/embedded deployment
  in mind; converting the trained model to TensorFlow Lite would be a
  natural next step for deployment on resource-constrained devices.

---

# 9. Conclusion

This project demonstrates a complete, practical computer vision pipeline —
combining a pretrained deep-learning face detector with a transfer-learned
MobileNetV2 classifier — to solve a real-world monitoring problem in real
time, on ordinary CPU hardware, entirely from the command line.

---

# 10. How to Run

Full setup and usage instructions are in [`README.md`](../README.md) at the
repository root, covering: environment setup, downloading the face
detector and dataset, training, and running inference on images, video
files, and a live webcam.

# 11. Repository

GitHub: `https://github.com/{your-username}/{your-repo-name}`
